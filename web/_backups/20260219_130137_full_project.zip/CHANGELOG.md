# QuoteSync Changelog

This file is append-only.
Each entry includes a manifest reference for quick revert/compare.

## [20260209_134308] (250e8e0)

- Snapshot:
  - Manifest: .\_manifests\directory_manifest_20260209_134308_250e8e0.txt
  - Backups: .\_backups\*.20260209_134308.bak

- Notes:
  - (Add change notes under this entry when you apply a script)

